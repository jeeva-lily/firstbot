/**
 * AI Student Agent Hub - Frontend Chat Logic
 * Connects the chat interface to the FastAPI backend at http://127.0.0.1:8000
 */

document.addEventListener("DOMContentLoaded", () => {
    // 1. Find the chat input and send button from the HTML
    const chatForm = document.getElementById("chat-form");
    const messageInput = document.getElementById("message-input");
    const sendButton = document.getElementById("send-button");
    const chatMessages = document.getElementById("chat-messages");
    const chatContainer = document.getElementById("chat-container");
    const loadingIndicator = document.getElementById("loading-indicator");

    // Backend URL configuration
    const BACKEND_URL = "http://127.0.0.1:8000";

    /**
     * Formats current time into HH:MM AM/PM
     */
    function formatTime(date = new Date()) {
        return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }

    /**
     * Automatically scrolls chat container to the bottom
     */
    function scrollToBottom() {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    /**
     * Shows or hides the "AI is thinking..." loading indicator
     */
    function setLoading(isLoading) {
        if (isLoading) {
            loadingIndicator.style.display = "flex";
            const bubble = loadingIndicator.querySelector(".message-bubble");
            if (bubble) {
                bubble.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 0.88rem; color: #94a3b8;">AI is thinking...</span>
                        <div class="typing-indicator" aria-label="AI is thinking">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                `;
            }
            sendButton.disabled = true;
            messageInput.disabled = true;
        } else {
            loadingIndicator.style.display = "none";
            sendButton.disabled = false;
            messageInput.disabled = false;
        }
        scrollToBottom();
    }

    /**
     * Displays the user's message on the right side of the chat area
     */
    function appendUserMessage(text) {
        const messageWrapper = document.createElement("div");
        messageWrapper.className = "message-wrapper user-message";

        messageWrapper.innerHTML = `
            <div class="avatar user-avatar" aria-hidden="true">U</div>
            <div class="message-content">
                <div class="message-sender">You</div>
                <div class="message-bubble">
                    <p></p>
                </div>
                <span class="message-time">${formatTime()}</span>
            </div>
        `;

        messageWrapper.querySelector(".message-bubble p").textContent = text;
        chatMessages.appendChild(messageWrapper);
        scrollToBottom();
    }

    /**
     * Displays the AI response on the left side of the chat area
     */
    function appendAiMessage(text, isError = false) {
        const messageWrapper = document.createElement("div");
        messageWrapper.className = "message-wrapper ai-message";

        messageWrapper.innerHTML = `
            <div class="avatar ai-avatar" aria-hidden="true">
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none">
                    <rect x="3" y="11" width="18" height="10" rx="2"></rect>
                    <circle cx="12" cy="5" r="2"></circle>
                    <path d="M12 7v4"></path>
                    <line x1="8" y1="16" x2="8.01" y2="16"></line>
                    <line x1="16" y1="16" x2="16.01" y2="16"></line>
                </svg>
            </div>
            <div class="message-content">
                <div class="message-sender">AI Assistant</div>
                <div class="message-bubble" ${isError ? 'style="border-color: rgba(239, 68, 68, 0.4); background: rgba(239, 68, 68, 0.1);"' : ""}>
                    <p></p>
                </div>
                <span class="message-time">${formatTime()}</span>
            </div>
        `;

        messageWrapper.querySelector(".message-bubble p").textContent = text;
        chatMessages.appendChild(messageWrapper);
        scrollToBottom();
    }

    /**
     * Handles message submission to backend API
     */
    chatForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        // Get message from input & prevent sending empty message
        const userMessage = messageInput.value.trim();
        if (!userMessage) return;

        // Display user message in chat area
        appendUserMessage(userMessage);

        // Clear input after sending
        messageInput.value = "";

        // Show "AI is thinking..." loading indicator
        setLoading(true);

        try {
            // Send POST request to ${BACKEND_URL}/chat
            const response = await fetch(`${BACKEND_URL}/chat`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    message: userMessage
                })
            });

            // Handle non-200 backend responses
            if (!response.ok) {
                let errorDetail = `Server error (${response.status})`;
                try {
                    const errorJson = await response.json();
                    if (errorJson && errorJson.detail) {
                        errorDetail = errorJson.detail;
                    }
                } catch (_) {
                    // Non-JSON response
                }
                appendAiMessage(`Error: ${errorDetail}`, true);
                return;
            }

            // Read JSON response and display AI reply
            const data = await response.json();
            const aiReply = data.response || "No response received.";
            appendAiMessage(aiReply);

        } catch (error) {
            console.error("Fetch network error:", error);
            // Handle network connection failure
            appendAiMessage(
                `Unable to connect to the backend server. Please make sure the FastAPI server is running at ${BACKEND_URL}.`,
                true
            );
        } finally {
            // Hide loading indicator and re-focus input
            setLoading(false);
            messageInput.focus();
        }
    });

    // Focus input on load
    messageInput.focus();
});
