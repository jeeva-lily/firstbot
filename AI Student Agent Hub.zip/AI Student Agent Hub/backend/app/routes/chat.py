from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.gemini_service import generate_ai_response

router = APIRouter()


# Pydantic request model
class ChatRequest(BaseModel):
    message: str


@router.post("/chat")
def chat(request: ChatRequest):
    """
    POST /chat endpoint: receives a user message and returns Gemini's response.
    """
    try:
        ai_reply = generate_ai_response(request.message)
        return {"response": ai_reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
