from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes.chat import router as chat_router

app = FastAPI(title="AI Student Agent Hub API")

# Configure CORS Middleware for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Connect the chat router to make the /chat POST endpoint available
app.include_router(chat_router)


@app.get("/")
def read_root():
    return {"message": "AI Student Agent Hub API is running"}


@app.get("/health")
def health_check():
    return {"status": "healthy"}
