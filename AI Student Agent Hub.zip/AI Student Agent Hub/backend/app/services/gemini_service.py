import os
from pathlib import Path
from dotenv import load_dotenv
from google import genai

# Load environment variables from backend/.env
env_path = Path(__file__).resolve().parent.parent.parent / ".env"
load_dotenv(dotenv_path=env_path)
load_dotenv()

# Read the API key from the GEMINI_API_KEY environment variable
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Initialize the Gemini client
client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None

# Supported Gemini Flash models (with fallback for temporary high demand)
FLASH_MODELS = ["gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-3.8-flash"]


def generate_ai_response(message: str) -> str:
    """
    Sends a message to the Gemini API and returns the AI-generated text response.
    """
    if not GEMINI_API_KEY or not client:
        raise ValueError("GEMINI_API_KEY is not set. Please check your backend/.env file.")

    last_error = None
    for model_name in FLASH_MODELS:
        try:
            response = client.models.generate_content(
                model=model_name,
                contents=message,
            )
            if response and response.text:
                return response.text
        except Exception as e:
            last_error = e
            # Try the next model if temporary demand spike occurs
            continue

    # If all models fail, raise error with sanitized message
    error_message = str(last_error) if last_error else "Failed to generate AI response"
    if GEMINI_API_KEY and GEMINI_API_KEY in error_message:
        error_message = error_message.replace(GEMINI_API_KEY, "[REDACTED]")

    raise RuntimeError(f"Gemini API request failed: {error_message}")
